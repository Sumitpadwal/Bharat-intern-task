# -Ineternship-task
Task1 and Task 3 is completed
